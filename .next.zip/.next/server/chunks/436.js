exports.id = 436;
exports.ids = [436];
exports.modules = {

/***/ 51105:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 80731))

/***/ }),

/***/ 1784:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 90125, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 86249, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 79775, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 61522, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 13100, 23))

/***/ }),

/***/ 23209:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 7649, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 27977, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 55821));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 62073));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 62095))

/***/ }),

/***/ 28123:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 7649, 23))

/***/ }),

/***/ 80731:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(31621);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* __next_internal_client_entry_do_not_use__ default auto */ 


const ErrorHandleer = ({ error , reset  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "w-screen h-screen bg-gray flex justify-center items-center fixed z-10",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    children: error.message ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        children: error.message
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        children: "something went wrong."
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex justify-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            onClick: reset,
                            className: "mr-5 border rounded-md p-2 hover:bg-primary first-line:hover:text-white",
                            children: "try again"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                            href: "/",
                            className: "border rounded-md p-2 hover:bg-primary first-line:hover:text-white",
                            children: "Go back to home"
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ErrorHandleer);


/***/ }),

/***/ 31394:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const url = "https://brightapi.merahitechnologies.com/api";
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (url);


/***/ }),

/***/ 62073:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(89996);
/* __next_internal_client_entry_do_not_use__ default auto */ 


function Section({ children  }) {
    const ref = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const isInView = (0,framer_motion__WEBPACK_IMPORTED_MODULE_2__/* .useInView */ .Y)(ref, {
        once: true
    });
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        ref: ref,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            style: {
                transform: isInView ? "none" : "translatey(400px)",
                opacity: isInView ? 1 : 0,
                transition: "all 0.9s cubic-bezier(0.17, 0.55, 0.55, 1) 0.5s"
            },
            children: children
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Section);


/***/ }),

/***/ 11688:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(48421);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);



const Spinner = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "w-screen h-screen bg-gray flex justify-center items-center",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                src: "/loading.gif",
                width: 50,
                height: 50,
                alt: "spinner"
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Spinner);


/***/ }),

/***/ 55821:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ TheHeader)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(48421);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(31621);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _headlessui_react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(32513);
/* harmony import */ var _headlessui_react__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(86235);
/* harmony import */ var _headlessui_react__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(8666);
/* harmony import */ var _headlessui_react__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(94702);
/* harmony import */ var _react_icons_all_files_hi_HiChevronDown__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(12124);
/* harmony import */ var _react_icons_all_files_fc_FcMenu__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(93600);
/* harmony import */ var _react_icons_all_files_fa_FaTimes__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(76173);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(59483);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_navigation__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _Spinner__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(11688);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(40248);
/* harmony import */ var _app_url__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(31394);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(42714);
/* __next_internal_client_entry_do_not_use__ default auto */ 












const getDestinations = async ()=>{
    const res = await axios__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z.get(`${_app_url__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z}/destinations`).then((response)=>response.data);
    return res;
};
// const destinationData = getDestinations()
function classNames(...classes) {
    return classes.filter(Boolean).join(" ");
}
function TheHeader() {
    const [mobileMenuOpen, setMobileMenuOpen] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const path = (0,next_navigation__WEBPACK_IMPORTED_MODULE_4__.usePathname)();
    //  const data = use(destinationData)
    const { data , isLoading , isFetching , error , isSuccess  } = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_8__/* .useQuery */ .a)({
        queryKey: [
            "destinations"
        ],
        queryFn: ()=>getDestinations()
    });
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (isSuccess && data) {
            console.log(data);
        }
    }, [
        isSuccess,
        data
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("header", {
            className: "bg-white top-0 z-50 shadow-lg",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("nav", {
                    className: "mx-auto flex max-w-7xl items-center justify-between p-6 lg:px-8",
                    "aria-label": "Global",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "flex lg:flex-1",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                href: "/",
                                className: "flex items-center -m-1.5 p-1.5",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        className: "h-8 w-auto",
                                        src: "/logo.png",
                                        width: 80,
                                        height: 80,
                                        priority: true,
                                        alt: ""
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "ml-2 text-primary font-bold",
                                        children: "Your Company"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "flex lg:hidden",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                type: "button",
                                className: "-m-2.5 inline-flex items-center justify-center rounded-md p-2.5 text-gray-700",
                                onClick: ()=>setMobileMenuOpen(true),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "sr-only",
                                        children: "Open main menu"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_icons_all_files_fc_FcMenu__WEBPACK_IMPORTED_MODULE_9__/* .FcMenu */ .S, {
                                        className: "h-6 w-6",
                                        "aria-hidden": "true"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_headlessui_react__WEBPACK_IMPORTED_MODULE_10__/* .Popover */ .J.Group, {
                            className: "hidden lg:flex lg:gap-x-6",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                    href: "/",
                                    className: path === "/" ? "border-b-4 border-indigo-500 text-sm font-semibold leading-6 text-gray-900" : "text-sm font-semibold leading-6 text-gray-900 hover:border-b-4 border-indigo-500",
                                    children: "Home"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                    href: "/about",
                                    className: path === "/about" ? "border-b-4 border-indigo-500 text-sm font-semibold leading-6 text-gray-900" : "text-sm font-semibold leading-6 text-gray-900 hover:border-b-4 border-indigo-500",
                                    children: "About"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_headlessui_react__WEBPACK_IMPORTED_MODULE_10__/* .Popover */ .J, {
                                    className: "relative",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_headlessui_react__WEBPACK_IMPORTED_MODULE_10__/* .Popover */ .J.Button, {
                                            className: "flex items-center gap-x-1 text-sm font-semibold leading-6 text-gray-900",
                                            children: [
                                                "Destination",
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_icons_all_files_hi_HiChevronDown__WEBPACK_IMPORTED_MODULE_11__/* .HiChevronDown */ .k, {
                                                    className: "h-5 w-5 flex-none text-gray-400",
                                                    "aria-hidden": "true"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_12__/* .Transition */ .u, {
                                            as: react__WEBPACK_IMPORTED_MODULE_1__.Fragment,
                                            enter: "transition ease-out duration-200",
                                            enterFrom: "opacity-0 translate-y-1",
                                            enterTo: "opacity-100 translate-y-0",
                                            leave: "transition ease-in duration-150",
                                            leaveFrom: "opacity-100 translate-y-0",
                                            leaveTo: "opacity-0 translate-y-1",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_10__/* .Popover */ .J.Panel, {
                                                className: "absolute -left-8 top-full z-10 mt-3 w-screen max-w-xs overflow-hidden rounded-3xl bg-white shadow-lg ring-1 ring-gray-900/5",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "p-4",
                                                    children: data ? data.map((destination)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "group relative flex items-center gap-x-6 rounded-lg p-4 text-sm leading-6 hover:bg-gray-50",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "flex-auto hover:text-amber-400",
                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_headlessui_react__WEBPACK_IMPORTED_MODULE_10__/* .Popover */ .J.Button, {
                                                                    as: (next_link__WEBPACK_IMPORTED_MODULE_3___default()),
                                                                    href: `/destination/${destination.id}`,
                                                                    className: "block font-semibold text-gray-900",
                                                                    children: [
                                                                        destination.title,
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                            className: "absolute inset-0"
                                                                        })
                                                                    ]
                                                                })
                                                            })
                                                        }, destination.id)) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Spinner__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {})
                                                })
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                    href: "/services",
                                    className: path === "/services" ? "border-b-4 border-indigo-500 text-sm font-semibold leading-6 text-gray-900" : "text-sm font-semibold leading-6 text-gray-900 hover:border-b-4 border-indigo-500",
                                    children: "Services"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                    href: "/blog",
                                    className: path === "/blog" ? "border-b-4 border-indigo-500 text-sm font-semibold leading-6 text-gray-900" : "text-sm font-semibold leading-6 text-gray-900 hover:border-b-4 border-indigo-500",
                                    children: "Blog"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                    href: "#contactarea",
                                    className: path === "/contact" ? "border-b-4 border-indigo-500 text-sm font-semibold leading-6 text-gray-900" : "text-sm font-semibold leading-6 text-gray-900 hover:border-b-4 border-indigo-500",
                                    children: "Contact"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                    href: "/applay",
                                    className: path === "/applay" ? "border-b-4 border-indigo-500 text-sm font-semibold leading-6 text-gray-900" : "text-sm font-semibold leading-6 text-gray-900 hover:border-b-4 border-indigo-500",
                                    children: "Applay"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                    href: "/bookconsulting",
                                    className: path === "/bookconsulting" ? "border-b-4 border-indigo-500 text-sm font-semibold leading-6 text-gray-900" : "text-sm font-semibold leading-6 text-gray-900 hover:border-b-4 border-indigo-500",
                                    children: "Book free Consulting"
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_headlessui_react__WEBPACK_IMPORTED_MODULE_13__/* .Dialog */ .V, {
                    as: "div",
                    className: "lg:hidden",
                    open: mobileMenuOpen,
                    onClose: setMobileMenuOpen,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "fixed inset-0 z-10"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_headlessui_react__WEBPACK_IMPORTED_MODULE_13__/* .Dialog */ .V.Panel, {
                            className: "fixed inset-y-0 right-0 z-10 w-full overflow-y-auto bg-white px-6 py-6 sm:max-w-sm sm:ring-1 sm:ring-gray-900/10",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex items-center justify-between",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                            href: "#",
                                            className: "-m-1.5 p-1.5",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "sr-only",
                                                    children: "Your Company"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                    className: "h-8 w-auto",
                                                    src: "/logo.png",
                                                    width: 80,
                                                    height: 80,
                                                    priority: true,
                                                    alt: ""
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                            type: "button",
                                            className: "-m-2.5 rounded-md p-2.5 text-gray-700",
                                            onClick: ()=>setMobileMenuOpen(false),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "sr-only",
                                                    children: "Close menu"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_icons_all_files_fa_FaTimes__WEBPACK_IMPORTED_MODULE_14__/* .FaTimes */ .a, {
                                                    className: "h-6 w-6",
                                                    "aria-hidden": "true"
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "mt-6 flow-root",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "-my-6 divide-y divide-gray-500/10",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "space-y-2 py-6",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                    href: "/",
                                                    className: "-mx-3 block rounded-lg px-3 py-2 text-base font-semibold leading-7 text-gray-900 hover:bg-gray-50",
                                                    children: "Home"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                    href: "/about",
                                                    className: "-mx-3 block rounded-lg px-3 py-2 text-base font-semibold leading-7 text-gray-900 hover:bg-gray-50",
                                                    children: "About"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_15__/* .Disclosure */ .p, {
                                                    as: "div",
                                                    className: "-mx-3",
                                                    children: ({ open  })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                            children: [
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_headlessui_react__WEBPACK_IMPORTED_MODULE_15__/* .Disclosure */ .p.Button, {
                                                                    className: "flex w-full items-center justify-between rounded-lg py-2 pl-3 pr-3.5 text-base font-semibold leading-7 hover:bg-gray-50",
                                                                    children: [
                                                                        "Destinations",
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_icons_all_files_hi_HiChevronDown__WEBPACK_IMPORTED_MODULE_11__/* .HiChevronDown */ .k, {
                                                                            className: classNames(open ? "rotate-180" : "", "h-5 w-5 flex-none"),
                                                                            "aria-hidden": "true"
                                                                        })
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_15__/* .Disclosure */ .p.Panel, {
                                                                    className: "mt-2 space-y-2",
                                                                    children: data ? data.map((destination)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_15__/* .Disclosure */ .p.Button, {
                                                                            as: "Link",
                                                                            href: `/destination/${destination.id}`,
                                                                            className: "block rounded-lg py-2 pl-6 pr-3 text-sm font-semibold leading-7 text-gray-900 hover:bg-gray-50",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                className: "hover:text-amber-500",
                                                                                children: destination.title
                                                                            })
                                                                        }, destination.id)) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Spinner__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {})
                                                                })
                                                            ]
                                                        })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                    href: "/Services",
                                                    className: "-mx-3 block rounded-lg px-3 py-2 text-base font-semibold leading-7 text-gray-900 hover:bg-gray-50",
                                                    children: "Services"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                    href: "/blog",
                                                    className: "-mx-3 block rounded-lg px-3 py-2 text-base font-semibold leading-7 text-gray-900 hover:bg-gray-50",
                                                    children: "Blog"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                    href: "#contactarea",
                                                    className: "-mx-3 block rounded-lg px-3 py-2 text-base font-semibold leading-7 text-gray-900 hover:bg-gray-50",
                                                    children: "Contact"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                    href: "/applay",
                                                    className: "-mx-3 block rounded-lg px-3 py-2 text-base font-semibold leading-7 text-gray-900 hover:bg-gray-50",
                                                    children: "Applay"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                    href: "/bookconsulting",
                                                    className: "-mx-3 block rounded-lg px-3 py-2 text-base font-semibold leading-7 text-gray-900 hover:bg-gray-50",
                                                    children: "Book free Consulting"
                                                })
                                            ]
                                        })
                                    })
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
}


/***/ }),

/***/ 62095:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(75218);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(98417);
/* harmony import */ var _tanstack_react_query_devtools__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(64154);
/* __next_internal_client_entry_do_not_use__ default auto */ 



function Providers({ children  }) {
    const [client] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(new _tanstack_react_query__WEBPACK_IMPORTED_MODULE_2__/* .QueryClient */ .S({
        defaultOptions: {
            queries: {
                staleTime: 5000
            }
        }
    }));
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_tanstack_react_query__WEBPACK_IMPORTED_MODULE_3__/* .QueryClientProvider */ .aH, {
        client: client,
        children: [
            children,
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tanstack_react_query_devtools__WEBPACK_IMPORTED_MODULE_4__/* .ReactQueryDevtools */ .t, {
                initialIsOpen: false
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Providers);


/***/ }),

/***/ 95566:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(21313);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`C:\Users\hp\projects\bright-way-front-end\app\error.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ }),

/***/ 55685:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ RootLayout),
  metadata: () => (/* binding */ metadata)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/next/font/google/target.css?{"path":"app\\layout.js","import":"Inter","arguments":[{"subsets":["latin"],"display":"swap"}],"variableName":"inter"}
var target_path_app_layout_js_import_Inter_arguments_subsets_latin_display_swap_variableName_inter_ = __webpack_require__(46521);
var target_path_app_layout_js_import_Inter_arguments_subsets_latin_display_swap_variableName_inter_default = /*#__PURE__*/__webpack_require__.n(target_path_app_layout_js_import_Inter_arguments_subsets_latin_display_swap_variableName_inter_);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/react.shared-subset.js
var react_shared_subset = __webpack_require__(7887);
// EXTERNAL MODULE: ./app/globals.css
var globals = __webpack_require__(92817);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(34834);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./components/TopBar.jsx



const TopBar = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "bg-primary flex justify-center items-center h-16 sticky top-0 z-50",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                className: "text-white text-xs md:text-lg",
                children: [
                    "1000+ Scholarships are waiting for you in ",
                    new Date().getFullYear()
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                href: "/applay",
                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                    className: "border-white border-2 text:xs text-white m-2 px-2 py-1 lg:px-10 lg:m-4 rounded-md lg:text-xl",
                    children: "Apply Now"
                })
            })
        ]
    });
};
/* harmony default export */ const components_TopBar = (TopBar);

// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(21313);
;// CONCATENATED MODULE: ./components/TheHeader.jsx

const proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\hp\projects\bright-way-front-end\components\TheHeader.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const TheHeader = (__default__);
// EXTERNAL MODULE: ./node_modules/@react-icons/all-files/fa/FaFacebookSquare.js
var FaFacebookSquare = __webpack_require__(39231);
// EXTERNAL MODULE: ./node_modules/@react-icons/all-files/im/ImTelegram.js
var ImTelegram = __webpack_require__(41977);
// EXTERNAL MODULE: ./node_modules/@react-icons/all-files/fa/FaInstagramSquare.js
var FaInstagramSquare = __webpack_require__(244);
// EXTERNAL MODULE: ./node_modules/@react-icons/all-files/si/SiTiktok.js
var SiTiktok = __webpack_require__(6695);
// EXTERNAL MODULE: ./node_modules/@react-icons/all-files/io/IoLogoYoutube.js
var IoLogoYoutube = __webpack_require__(26946);
// EXTERNAL MODULE: ./node_modules/@react-icons/all-files/hi/HiOutlineMail.js
var HiOutlineMail = __webpack_require__(11048);
// EXTERNAL MODULE: ./node_modules/@react-icons/all-files/fa/FaLinkedinIn.js
var FaLinkedinIn = __webpack_require__(2327);
// EXTERNAL MODULE: ./components/Section.jsx
var Section = __webpack_require__(59700);
;// CONCATENATED MODULE: ./components/TheFooter.jsx









// import { BsFacebook, BsTelegram, BsInstagram, BsTiktok, BsYoutube } from 'react-icons/bs'
// import { HiOutlineMail,FaLinkedinIn } from 'react-icons/ai'


const TheFooter = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("footer", {
        className: "max-w-full bg-primary pt-10 lg:pt-20",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Section/* default */.ZP, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "text-center text-white text-xl lg:text-3xl font-bold",
                        children: "Follow Us On"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "hidden lg:flex flex-row justify-center gap-10 mt-14 lg:mt-20",
                        id: "contactarea",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                href: "/",
                                className: "rounded-full p-2 lg:p-5 bg-blue-800 transition ease-in-out delay-150  hover:rotate-12  duration-1000 ",
                                children: [
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx(FaFacebookSquare/* FaFacebookSquare */.R, {
                                        size: 50,
                                        className: "text-white"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                href: "/",
                                className: "rounded-full p-2 lg:p-5 bg-blue-400 transition ease-in-out delay-150  hover:rotate-12  duration-1000",
                                children: [
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx(ImTelegram/* ImTelegram */.c, {
                                        size: 50,
                                        className: "text-white"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                href: "/",
                                className: "rounded-full p-2 lg:p-5 bg-black transition ease-in-out delay-150  hover:rotate-12  duration-1000",
                                children: [
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx(FaInstagramSquare/* FaInstagramSquare */.d, {
                                        size: 50,
                                        className: "text-white"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                href: "/",
                                className: "rounded-full p-2 lg:p-5 bg-red-500 transition ease-in-out delay-150  hover:rotate-12  duration-1000",
                                children: [
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx(HiOutlineMail/* HiOutlineMail */.Z, {
                                        size: 50,
                                        className: "text-white"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                href: "/",
                                className: "rounded-full p-2 lg:p-5 bg-blue-600 transition ease-in-out delay-150  hover:rotate-12  duration-1000",
                                children: [
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx(FaLinkedinIn/* FaLinkedinIn */.B, {
                                        size: 50,
                                        className: "text-white"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                href: "/",
                                className: "rounded-full p-2 lg:p-5 bg-black transition ease-in-out delay-150  hover:rotate-12  duration-1000",
                                children: [
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx(SiTiktok/* SiTiktok */.n, {
                                        size: 50,
                                        className: "text-white"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                href: "/",
                                className: "rounded-full p-2 lg:p-5 bg-red-600 transition ease-in-out delay-150  hover:rotate-12  duration-1000",
                                children: [
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx(IoLogoYoutube/* IoLogoYoutube */.t, {
                                        size: 50,
                                        className: "text-white"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "w-full flex flex-row justify-center lg:hidden gap-2 mt-5",
                        id: "contactarea",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                href: "/",
                                className: "rounded-full p-2 lg:p-5 bg-blue-800 transition ease-in-out delay-150  hover:rotate-12  duration-1000 ",
                                children: [
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx(FaFacebookSquare/* FaFacebookSquare */.R, {
                                        size: 20,
                                        className: "text-white"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                href: "/",
                                className: "rounded-full p-2 lg:p-5 bg-blue-400 transition ease-in-out delay-150  hover:rotate-12  duration-1000",
                                children: [
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx(ImTelegram/* ImTelegram */.c, {
                                        size: 20,
                                        className: "text-white"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                href: "/",
                                className: "rounded-full p-2 lg:p-5 bg-black transition ease-in-out delay-150  hover:rotate-12  duration-1000",
                                children: [
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx(FaInstagramSquare/* FaInstagramSquare */.d, {
                                        size: 20,
                                        className: "text-white"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                href: "/",
                                className: "rounded-full p-2 lg:p-5 bg-red-500 transition ease-in-out delay-150  hover:rotate-12  duration-1000",
                                children: [
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx(HiOutlineMail/* HiOutlineMail */.Z, {
                                        size: 20,
                                        className: "text-white"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                href: "/",
                                className: "rounded-full p-2 lg:p-5 bg-blue-600 transition ease-in-out delay-150  hover:rotate-12  duration-1000",
                                children: [
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx(FaLinkedinIn/* FaLinkedinIn */.B, {
                                        size: 20,
                                        className: "text-white"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                href: "/",
                                className: "rounded-full p-2 lg:p-5 bg-black transition ease-in-out delay-150  hover:rotate-12  duration-1000",
                                children: [
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx(SiTiktok/* SiTiktok */.n, {
                                        size: 20,
                                        className: "text-white"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                href: "/",
                                className: "rounded-full p-2 lg:p-5 bg-red-600 transition ease-in-out delay-150  hover:rotate-12  duration-1000",
                                children: [
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx(IoLogoYoutube/* IoLogoYoutube */.t, {
                                        size: 20,
                                        className: "text-white"
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-32 w-full mx-auto px-5 lg:px-20 mt-10 lg:mt-14",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Section/* default */.ZP, {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "text-white text-2xl",
                                children: "Address One"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "text-white text-xl",
                                children: "1. Bole Street Addis Ababa, Ethiopia"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "text-white text-xl",
                                children: "+251920907878    +251910813571"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "mt-10 lg:mt-14",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("iframe", {
                                    src: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d252226.0134836966!2d38.4836695395734!3d8.969248113153492!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x164b84f21691961f%3A0x822a438ed5adcc15!2sAddis%20Ababa%2C%20Ethiopia!5e0!3m2!1sen!2snl!4v1684613347486!5m2!1sen!2snl",
                                    className: "w-full h-96",
                                    style: {
                                        border: 0
                                    },
                                    allowFullScreen: true,
                                    loading: "lazy",
                                    referrerPolicy: "no-referrer-when-downgrade"
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Section/* default */.ZP, {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "text-white text-2xl",
                                children: "Address Two"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "text-white text-xl",
                                children: "2. 7523 24th Ave SW Seattle, Washington"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "text-white text-xl",
                                children: "206-353-5373"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "mt-10 lg:mt-14",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("iframe", {
                                    src: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2693.6958103715006!2d-122.36837650829688!3d47.53478491864081!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x5490417277c8cbf3%3A0x4ff6934b6aa5dfaa!2s7523%2024th%20Ave%20SW%2C%20Seattle%2C%20WA%2098106%2C%20USA!5e0!3m2!1sen!2sca!4v1687348006478!5m2!1sen!2sca",
                                    className: "w-full h-96",
                                    style: {
                                        border: 0
                                    },
                                    allowfullscreen: "",
                                    loading: "lazy",
                                    referrerpolicy: "no-referrer-when-downgrade"
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "w-full bg-white text-center mt-14 pt-6 pb-6",
                children: "Copyright \xa9 2023 | Developed by Merahi Technologies"
            })
        ]
    });
};
/* harmony default export */ const components_TheFooter = (TheFooter);

// EXTERNAL MODULE: ./app/loading.jsx + 1 modules
var loading = __webpack_require__(19675);
;// CONCATENATED MODULE: ./utils/provider.jsx

const provider_proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\hp\projects\bright-way-front-end\utils\provider.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: provider_esModule, $$typeof: provider_$$typeof } = provider_proxy;
const provider_default_ = provider_proxy.default;


/* harmony default export */ const provider = (provider_default_);
;// CONCATENATED MODULE: ./app/layout.js
/* eslint-disable @next/next/no-sync-scripts */ 








const metadata = {
    title: {
        template: "%s",
        default: "Bright Consultancy"
    },
    description: ""
};
function RootLayout({ children  }) {
    return /*#__PURE__*/ jsx_runtime_.jsx("html", {
        lang: "en",
        children: /*#__PURE__*/ jsx_runtime_.jsx("body", {
            className: (target_path_app_layout_js_import_Inter_arguments_subsets_latin_display_swap_variableName_inter_default()).className,
            suppressHydrationWarning: true,
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(provider, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(components_TopBar, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(TheHeader, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(react_shared_subset.Suspense, {
                        fallback: /*#__PURE__*/ jsx_runtime_.jsx(loading["default"], {}),
                        children: children
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(components_TheFooter, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx("script", {
                        src: "https://cdn.botpress.cloud/webchat/v0/inject.js"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("script", {
                        src: "https://mediafiles.botpress.cloud/d55d4fce-33fd-4014-967d-f45258752372/webchat/config.js",
                        defer: true
                    })
                ]
            })
        })
    });
}


/***/ }),

/***/ 19675:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ app_loading)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/react.shared-subset.js
var react_shared_subset = __webpack_require__(7887);
;// CONCATENATED MODULE: ./public/loading.gif
/* harmony default export */ const loading = ({"src":"/_next/static/media/loading.cf3c557d.gif","height":54,"width":54,"blurWidth":0,"blurHeight":0});
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(10993);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./app/loading.jsx




const loading_loading = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "w-screen h-screen bg-gray flex justify-center items-center",
            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                src: "/loading.gif",
                width: 50,
                height: 50,
                alt: "spinner"
            })
        })
    });
};
/* harmony default export */ const app_loading = (loading_loading);


/***/ }),

/***/ 59700:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ZP: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports __esModule, $$typeof */
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(21313);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`C:\Users\hp\projects\bright-way-front-end\components\Section.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ }),

/***/ 83174:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(93180);
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__);
  

  /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props) => {
    const imageData = {"type":"image/x-icon","sizes":"any"}
    const imageUrl = (0,next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__.fillMetadataSegment)(".", props.params, "favicon.ico")

    return [{
      ...imageData,
      url: imageUrl + "",
    }]
  });

/***/ }),

/***/ 92817:
/***/ (() => {



/***/ })

};
;