"use strict";
exports.id = 631;
exports.ids = [631];
exports.modules = {

/***/ 5611:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Z: () => (/* binding */ OurTeams)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/react-multi-carousel/index.js
var react_multi_carousel = __webpack_require__(8801);
// EXTERNAL MODULE: ./node_modules/react-multi-carousel/lib/styles.css
var styles = __webpack_require__(27915);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(48421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./components/Section.jsx
var Section = __webpack_require__(62073);
// EXTERNAL MODULE: ./components/Spinner.jsx
var Spinner = __webpack_require__(11688);
// EXTERNAL MODULE: ./node_modules/@material-tailwind/react/index.js
var react = __webpack_require__(18714);
;// CONCATENATED MODULE: ./components/MaterialTailwind.jsx
/* __next_internal_client_entry_do_not_use__ Card,CardHeader,CardBody,Typography auto */ 


// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/@tanstack/react-query/build/lib/useQuery.mjs + 8 modules
var useQuery = __webpack_require__(42714);
// EXTERNAL MODULE: ./node_modules/axios/lib/axios.js + 46 modules
var axios = __webpack_require__(40248);
// EXTERNAL MODULE: ./app/url.js
var url = __webpack_require__(31394);
;// CONCATENATED MODULE: ./components/OurTeams.jsx











const responsive = {
    desktop: {
        breakpoint: {
            max: 3000,
            min: 1024
        },
        items: 4,
        slidesToSlide: 1 // optional, default to 1.
    },
    tablet: {
        breakpoint: {
            max: 1024,
            min: 464
        },
        items: 3,
        slidesToSlide: 1 // optional, default to 1.
    },
    mobile: {
        breakpoint: {
            max: 464,
            min: 0
        },
        items: 2,
        slidesToSlide: 1 // optional, default to 1.
    }
};
const fetchTeams = async ()=>{
    const res = await axios/* default */.Z.get(`${url/* default */.Z}/get_teams`);
    return res.data;
};
function OurTeams() {
    const { data , isLoading , isSuccess  } = (0,useQuery/* useQuery */.a)({
        queryKey: [
            "ourTeams"
        ],
        queryFn: fetchTeams
    });
    (0,react_.useEffect)(()=>{
        if (isSuccess && data) {
            console.log("teams=", data);
        }
    }, [
        isSuccess,
        data
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx(react_multi_carousel["default"], {
        swipeable: true,
        draggable: false,
        showDots: false,
        responsive: responsive,
        ssr: true,
        infinite: true,
        autoPlay: true,
        autoPlaySpeed: 2000,
        keyboardControl: true,
        customTransition: "all 300ms",
        transitionDuration: 300,
        containerClass: "carousel-container",
        removeArrowOnDeviceType: [
            "desktop",
            "tablet",
            "mobile"
        ],
        dotListClass: "custom-dot-list-style",
        itemClass: "carousel-item-padding-40-px",
        children: isLoading ? /*#__PURE__*/ jsx_runtime_.jsx(Spinner/* default */.Z, {}) : data ? data.map((team)=>/*#__PURE__*/ jsx_runtime_.jsx(Section["default"], {
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "w-11/12 mx-auto block rounded-lg bg-white shadow-[0_2px_15px_-3px_rgba(0,0,0,0.07),0_10px_20px_-2px_rgba(0,0,0,0.04)] dark:bg-neutral-700",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "max-w-full overflow-hidden mb-10 min-h-[25rem] max-h-[25rem]",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                floated: false,
                                shadow: false,
                                color: "transparent",
                                className: "m-0 rounded-lg relative h-64 ",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: team.photo,
                                    fill: true,
                                    alt: "profile-picture",
                                    className: "border-none rounded-t-lg"
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react.CardBody, {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(react.Typography, {
                                        variant: "h6",
                                        color: "blue-gray",
                                        children: team.f_name + " " + team.m_name
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(react.Typography, {
                                        color: "gray",
                                        className: "mt-3 font-normal",
                                        children: team.quote
                                    })
                                ]
                            })
                        ]
                    })
                })
            }, team.id)) : /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "text-center text-lg text-red-500",
            children: "No Teams found"
        })
    });
}


/***/ }),

/***/ 74578:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(48421);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _Spinner__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(11688);
/* harmony import */ var _app_url__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(31394);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(42714);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(40248);
/* __next_internal_client_entry_do_not_use__ default auto */ 






const getDestinations = async ()=>{
    const res = await axios__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z.get(`${_app_url__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z}/destinations`).then((response)=>response.data);
    return res;
};
async function Packages() {
    const { data , isLoading , isFetching , error , isSuccess  } = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_6__/* .useQuery */ .a)({
        queryKey: [
            "destinations"
        ],
        queryFn: ()=>getDestinations()
    });
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (isSuccess && data) {
            console.log(data);
        }
    }, [
        isSuccess,
        data
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "min:w-screen bg-[url(/whobg.jpg)] flex flex-col justify-center items-center",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "text-center text-3xl text-white font-mono font-bold py-10",
                children: "Study Abroad Packages"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "grid grid-cols-2 gap-4 py-4 px-4 md:grid-cols-4 md:gap-10 md:px-28 md:py-10",
                children: isLoading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Spinner__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}) : data ? data?.map((destination)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-col justify-start items-center shadow-2xl rounded-md",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                className: "rounded-t-lg my-3",
                                src: destination.photo,
                                width: 150,
                                height: 80,
                                alt: "team photo"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                className: "mb-2 text-lg text-center text-white font-medium leading-tight",
                                children: destination.title
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "text-md text-center text-white font-medium leading-tight my-3 px-5 pb-1",
                                children: "Poland is attracting ever more students from abroad. The country offers world-class education at modest tuition fees. Apply and study now."
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: "text-primary-green text-lg font-medium p-2",
                                children: "See More"
                            })
                        ]
                    }, destination.id)) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "text-center text-lg text-red-500",
                    children: "No countries found"
                })
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Packages);


/***/ }),

/***/ 94481:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_multi_carousel__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8801);
/* harmony import */ var react_multi_carousel_lib_styles_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(27915);
/* harmony import */ var react_multi_carousel_lib_styles_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_multi_carousel_lib_styles_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(48421);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _Section__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(62073);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(68149);
/* harmony import */ var _app_url__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(31394);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(40248);
/* harmony import */ var _tanstack_react_query__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(42714);
/* __next_internal_client_entry_do_not_use__ default auto */ 









const responsive = {
    desktop: {
        breakpoint: {
            max: 3000,
            min: 1024
        },
        items: 2,
        slidesToSlide: 2 // optional, default to 1.
    },
    tablet: {
        breakpoint: {
            max: 1024,
            min: 464
        },
        items: 1,
        slidesToSlide: 1 // optional, default to 1.
    },
    mobile: {
        breakpoint: {
            max: 464,
            min: 0
        },
        items: 1,
        slidesToSlide: 1 // optional, default to 1.
    }
};
const getDestinations = async ()=>{
    const res = await axios__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z.get(`${_app_url__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z}/testimonials`).then((response)=>response.data);
    return res;
};
const SingleImageCarousel = ()=>{
    const { data , isSuccess  } = (0,_tanstack_react_query__WEBPACK_IMPORTED_MODULE_9__/* .useQuery */ .a)({
        queryKey: [
            "testimonials"
        ],
        queryFn: ()=>getDestinations()
    });
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_multi_carousel__WEBPACK_IMPORTED_MODULE_1__["default"], {
        swipeable: true,
        draggable: false,
        showDots: false,
        responsive: responsive,
        ssr: true,
        infinite: true,
        autoPlay: true,
        autoPlaySpeed: 4000,
        keyBoardControl: true,
        customTransition: "all 300ms",
        transitionDuration: 2000,
        removeArrowOnDeviceType: [
            "desktop",
            "tablet",
            "mobile"
        ],
        containerClass: "carousel-container",
        dotListClass: "custom-dot-list-style",
        itemClass: "carousel-item-padding-40-px",
        children: data ? data.map((testimonial)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Section__WEBPACK_IMPORTED_MODULE_4__["default"], {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "w-11/12 mx-auto rounded-md bg-white p-6 text-center  md:text-left md:min-h-[15rem] md:max-h-[15rem]",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "md:flex md:flex-row",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "mx-auto mb-6 flex  items-center justify-center md:mx-0 md:w-96 lg:mb-0",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                                    src: testimonial.photo,
                                    width: 250,
                                    height: 250,
                                    alt: "testimonials_image",
                                    className: "rounded-lg shadow-md dark:shadow-black/30 "
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "md:ml-6",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "mb-6 font-light text-neutral-500 dark:text-neutral-300",
                                        children: testimonial.message
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "mb-2 text-xl font-semibold text-neutral-800 dark:text-neutral-200",
                                        children: testimonial.full_name
                                    })
                                ]
                            })
                        ]
                    })
                })
            }, testimonial.id)) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "text-center text-lg text-red-500",
            children: "No testimonials found"
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SingleImageCarousel);


/***/ }),

/***/ 96981:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Z: () => (/* binding */ components_WhyChooseUs)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(48421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./public/honesty.png
/* harmony default export */ const honesty = ({"src":"/_next/static/media/honesty.ad0866d7.png","height":140,"width":140,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAY0lEQVR42g3DzwvBYAAA0Ifj50dxVNKcOEnSWrRGGqWchHJ13GVr//++Xo+gkFlJHaPAzQx3ByOJkj0yZ7na1IYcQ6mtJL7w9TG2sItLT5b+WidrhZ8eTFQaDy8BBph7u4J+ByNbC7INsxUSAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/panctual.png
/* harmony default export */ const panctual = ({"src":"/_next/static/media/panctual.60ad2ad4.png","height":157,"width":157,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAV0lEQVR42gXAsQqCQAAA0HcNHYUgJYSW4BI4KU7qcoK4ioP//zHCDUGjBgFKyaC3yCFIoqeHygyNQbT5YlRQ60Q/d3+nDBYVWsmqhNxsctglLwIoZD7eXJ0RBpqYtxU+AAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/integrity.png
/* harmony default export */ const integrity = ({"src":"/_next/static/media/integrity.d53c43b2.png","height":158,"width":158,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAYklEQVR42g3FOwrCQAAA0Sc2IohairCi1ipa+EFR1rAhprFLkyJHydWzDMwj+Eg2AJQWZv75wc6EwtHeS+3nouTmLolWTihgpHLVa7IdbJ1RO3iLsPa01Jqaq2DskUu+ojAAvWkK6M/YRfwAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/accessibility.png
/* harmony default export */ const accessibility = ({"src":"/_next/static/media/accessibility.71ac4735.png","height":127,"width":127,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAZklEQVR42g3IywoBUQAA0LP3BywUpZTYWdiykDwzqes2Yu7EakTND8yfz9RZHQBISl/65haGVgpXOU8PZ3tB7eJPMrZ0MhAFH26mgtzMwctdZ2RirWfjp6RylNnaiaKKRpJJCl17t1ZmEna5wtrpAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/accountability.png
/* harmony default export */ const accountability = ({"src":"/_next/static/media/accountability.f2687ee6.png","height":126,"width":126,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAZ0lEQVR42g3Iuw3CQBRE0VMAIQWQYCJIMBjEJ8ACwa6Qli0CV+A6CGjYLxjp3IGZj69BCWER/Hl4+RuiXJwtVb15+Eqrqhr3yGLH3luyddPKOuLQ2zhZy1EOsqTx1MWOgqOsqJLRagI0tRBD2AU9ngAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/acridited.png
/* harmony default export */ const acridited = ({"src":"/_next/static/media/acridited.ccf52ec7.png","height":260,"width":260,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAQ0lEQVR42mPADpgZ9IGQGcJhAmJThmQgNIXwGIGUOUMSQzKQBPIgKiSBAlFAEsiDCPgwpDEkA0kIDwiEGZSBUBirhQB0HQWRn60C6QAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/affordable.png
/* harmony default export */ const affordable = ({"src":"/_next/static/media/affordable.95a15c78.png","height":127,"width":127,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAVElEQVR42g3CsQpAUBQA0LPI7C9MrzeYKaUUKcqNhen9/y9wOpCEsHllSA6TUYNd5jRrrW7wEHqVolNj4a/WKSqD4AGXVWsWZDsao8khQfbahJD4AH0nDTrzakXjAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/convenience.png
/* harmony default export */ const convenience = ({"src":"/_next/static/media/convenience.d92780d9.png","height":137,"width":137,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAW0lEQVR42i3HMQqCUAAA0EdFQ3WRlmiJ4JNBhAV/UfTPTg6CkwqewIO7+LYH8HQH2CH3UPpvQ+0tSA7AWVTJBFzozYJF4yg38PKVKYyS1sQs+vmIks6VG2DvBCu98gvc7HvSpwAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
// EXTERNAL MODULE: ./components/Section.jsx
var Section = __webpack_require__(62073);
;// CONCATENATED MODULE: ./components/WhyChooseUs.jsx












const WhyChooseUs = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "grid grid-cols-2 md:grid-cols-4 gap-4 lg:gap-20 py-5  lg:py-20 w-11/12 mx-auto",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "flex justify-center",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Section["default"], {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: honesty,
                            alt: "honest icon",
                            style: {
                                maxWidth: 100,
                                maxHeight: 100
                            },
                            className: "backdrop-blur"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "lg:mt-5 text-lg",
                            children: "Honesty"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "flex justify-center",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Section["default"], {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: accountability,
                            alt: "accountability icon",
                            style: {
                                maxWidth: 100
                            }
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "lg:mt-5 text-lg",
                            children: "Accountablity"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "flex justify-center",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Section["default"], {
                    className: "mt-10 lg:mt-0",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: affordable,
                            alt: "affordable icon",
                            style: {
                                maxWidth: 100
                            }
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "lg:mt-5",
                            children: "Affordable"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "flex justify-center",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Section["default"], {
                    className: "mt-10 lg:mt-0",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: accessibility,
                            alt: "accessibility icon",
                            style: {
                                maxWidth: 100
                            }
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "lg:mt-5 text-lg",
                            children: "Accessible"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "flex justify-center",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Section["default"], {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: panctual,
                            alt: "panctual icon",
                            style: {
                                maxWidth: 100
                            }
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "lg:mt-5 text-lg",
                            children: "Punctuality"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "flex justify-center",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Section["default"], {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: convenience,
                            alt: "convenence icon",
                            style: {
                                maxWidth: 100
                            }
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "lg:mt-5 text-lg",
                            children: "Convenience"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "flex justify-center",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Section["default"], {
                    className: "mt-10 lg:mt-0",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: acridited,
                            alt: "acridit icon",
                            style: {
                                maxWidth: 100,
                                maxHeight: 100
                            }
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "lg:mt-5 text-lg text-center",
                            children: "Accredited"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "flex justify-center",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Section["default"], {
                    className: "mt-10 lg:mt-0",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: integrity,
                            alt: "convenence icon",
                            style: {
                                maxWidth: 100
                            }
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "lg:mt-5 text-lg text-center",
                            children: "Integrit"
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const components_WhyChooseUs = (WhyChooseUs);


/***/ })

};
;