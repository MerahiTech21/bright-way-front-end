"use client"

import { Card, CardHeader, CardBody, Typography } from "@material-tailwind/react";
export { Card, CardHeader,CardBody,Typography};