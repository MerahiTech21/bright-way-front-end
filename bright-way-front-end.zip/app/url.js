const url = 'https://brightapi.merahitechnologies.com/api'
export default url