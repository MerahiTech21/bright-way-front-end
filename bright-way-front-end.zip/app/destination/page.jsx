import React from 'react'

 const DestinationPage = () => {
  return (
    <div>DestinationPage</div>
  )
}
export default DestinationPage