import React from 'react'

const Applay = () => {
    
  return (
    <div className='w-full mx-auto'>
        <iframe src="https://applicant.merahitechnologies.com/" name="iframe_a" width="100%" height="1000px"  title="applicant form" ></iframe>
        </div>
  )
}

export default Applay