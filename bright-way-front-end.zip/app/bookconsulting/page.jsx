import React from 'react'

const BookConsulting = () => {
    
  return (
    <div className='w-full mx-auto bg[#E4F1FA] pt-5'>
        <iframe src="https://applicant.merahitechnologies.com/book-consulting" name="iframe_a" width="100%" height="1000px"  title="applicant form" ></iframe>
        </div>
  )
}

export default BookConsulting